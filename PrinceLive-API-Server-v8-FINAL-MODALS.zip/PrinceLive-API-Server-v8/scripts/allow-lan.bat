@echo off
chcp 65001 >nul
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo يجب تشغيل هذا الملف كمسؤول.
  pause
  exit /b 1
)
netsh advfirewall firewall add rule name="PrinceLive HTTP LAN Port 80" dir=in action=allow protocol=TCP localport=80 profile=private
if errorlevel 1 (
  echo تعذر إضافة قاعدة جدار الحماية.
) else (
  echo تم السماح باتصالات الشبكة الخاصة إلى PrinceLive على المنفذ 80.
)
pause
