@echo off
setlocal EnableExtensions
rem Find project root whether this BAT is in the root or a subfolder.
set "ROOT=%~dp0"
if not exist "%ROOT%server.js" (
  if exist "%ROOT%..\server.js" (
    for %%I in ("%ROOT%..") do set "ROOT=%%~fI\"
  )
)
if not exist "%ROOT%server.js" (
  echo ERROR: server.js not found. Put this BAT in the project root or one subfolder.
  pause
  exit /b 1
)
cd /d "%ROOT%"

echo Requesting FFmpeg stream stop through the local API...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:3001/api/stop' -TimeoutSec 5 | ConvertTo-Json -Depth 3 } catch { Write-Host 'API not responding; stream may already be stopped.' }"
echo.
echo This stops the stream only. Node API and Nginx remain running.
pause
