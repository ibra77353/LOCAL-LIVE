'use strict';
// Capture device report - a single diagnostic tool for both systems.
//
// Used by scripts\devices.bat on Windows and scripts/devices.sh on Linux,
// and it reads devices through the same capture layer the server uses:
//   Windows -> DirectShow (FFmpeg -list_devices)
//   Linux   -> V4L2 + ALSA (reads /dev, /sys and /proc)
// So any device shown here is the same one that appears in the admin panel's video device list.
//
// Usage:
//   node scripts/devices.js             <- devices plus the modes of each video device
//   node scripts/devices.js --no-caps   <- devices only (faster, no FFmpeg capability call)
//
// Exit codes: 0 the check succeeded (even when no device exists), 1 the check itself failed
// (unsupported platform, or FFmpeg cannot run on Windows where enumeration needs it).

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const capture = require(path.join(ROOT, 'lib', 'capture'));

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(path.join(ROOT, file), 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return null;
  }
}

const data = readJson('data.json') || {};
const cfg = readJson('config.json') || {};
const settings = data.settings || {};

// Same rule as server.js: a relative path is looked up next to server.js first, then in PATH,
// and on Windows the .exe suffix is tried as in the user settings.
function resolveTool(toolName) {
  const value = String(toolName || '').trim();
  if (!value || path.isAbsolute(value)) return value;
  const names = process.platform === 'win32' ? [value, `${value}.exe`] : [value];
  for (const name of names) {
    const candidate = path.join(ROOT, name);
    try { if (fs.statSync(candidate).isFile()) return candidate; } catch {}
  }
  return value;
}

const FFMPEG = resolveTool(process.env.FFMPEG_PATH || settings.ffmpegPath || cfg.ffmpegPath || 'ffmpeg');

function runFfmpeg(args) {
  return new Promise(resolve => {
    execFile(FFMPEG, args, { windowsHide: true, timeout: 20000, maxBuffer: 2 * 1024 * 1024 },
      (err, stdout, stderr) => resolve({ err, output: `${stderr || ''}\n${stdout || ''}`.trim() }));
  });
}

const line = (text = '') => process.stdout.write(`${text}\n`);

async function main() {
  const showCaps = !process.argv.includes('--no-caps');
  line('============================================================');
  line(' PrinceLive - device report');
  line('============================================================');
  line(`Platform      : ${process.platform} (${process.arch})`);
  line(`Capture engine: ${capture.engineLabel()} [${capture.engineName()}]`);
  line(`FFmpeg        : ${FFMPEG}`);

  const version = await runFfmpeg(['-hide_banner', '-version']);
  const versionLine = String(version.output || '').split(/\r?\n/).find(x => /ffmpeg version/i.test(x));
  if (versionLine) line(`FFmpeg version: ${versionLine.trim()}`);
  else line(`FFmpeg status : NOT RUNNABLE (${version.err ? version.err.message : 'no version output'})`);

  let result;
  try {
    result = await capture.discoverDevices(process.platform, runFfmpeg);
  } catch (err) {
    line('');
    line(`ERROR: ${err.message}`);
    line('Capture devices cannot be listed on this operating system.');
    process.exitCode = 1;
    return;
  }

  const video = result.video || [];
  const audio = result.audio || [];
  line('');
  line(`Video devices (${video.length}):`);
  video.forEach((device, index) => {
    const extra = device.label && device.label !== device.value ? ` [${device.value}]` : '';
    line(`  ${index + 1}. ${device.label || device.value}${extra}`);
  });
  if (!video.length) line('  (none found)');

  line(`Audio devices (${audio.length}):`);
  audio.forEach((device, index) => {
    const extra = device.label && device.label !== device.value ? ` [${device.value}]` : '';
    line(`  ${index + 1}. ${device.label || device.value}${extra}`);
  });
  if (!audio.length) line('  (none found)');

  line('');
  line(`Note: ${result.note}`);

  if (process.platform === 'win32') {
    line('Windows: a USB capture card must appear under "Cameras" (or "Imaging devices") in Device Manager,');
    line('and Settings > Privacy > Camera > "Allow desktop apps" must be enabled for FFmpeg to see it.');
  } else if (process.platform === 'linux') {
    line('Linux: add your user to the "video" (and "audio") group, then log in again to read /dev/video*.');
  }

  if (showCaps && video.length) {
    for (const device of video.slice(0, 8)) {
      line('');
      line(`Modes - ${device.value}:`);
      let args;
      try {
        args = capture.capabilitiesArgs(device.value);
      } catch (err) {
        line(`  not readable: ${err.message}`);
        continue;
      }
      const { err, output } = await runFfmpeg(args);
      const caps = capture.parseCapabilities(output);
      if (!caps.videoSizes.length) {
        line(`  not readable: ${err && !output ? err.message : 'the driver reported no video modes'}`);
        continue;
      }
      line(`  sizes   : ${caps.videoSizes.slice(0, 8).join(', ')}${caps.videoSizes.length > 8 ? ' ...' : ''}`);
      line(`  fps     : ${caps.frameRates.join(', ') || '-'}`);
      line(`  formats : ${caps.pixelFormats.join(', ') || '-'}`);
      const rec = caps.recommended;
      line(`  best    : ${rec.videoSize} @ ${rec.fps}fps ${rec.pixelFormat || ''}`.trimEnd());
    }
    if (video.length > 8) {
      line('');
      line(`(${video.length - 8} more device(s) were listed but not probed for modes.)`);
    }
  }

  line('');
  line('Done. The admin page reads the same list at GET /api/devices.');
}

main().catch(err => {
  line(`ERROR: ${err && err.message ? err.message : err}`);
  process.exitCode = 1;
});
